'use strict';

/**
 * @ngdoc service
 * @name smartApp.login
 * @description
 * # login
 * Service in the smartApp.
 */
angular.module('smartApp')
  .service('login', function () {
    // AngularJS will instantiate a singleton by calling "new" on this function
  });
