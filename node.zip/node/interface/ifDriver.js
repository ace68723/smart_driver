var modelUser = require("./../model/mysqlUser");
var Promise = require("bluebird");


function Driver(ir_pool) { 


    this.action = function(iv_token, iv_oid, iv_action ) {
    
    }
    
	
}; 

module.exports = Driver;
